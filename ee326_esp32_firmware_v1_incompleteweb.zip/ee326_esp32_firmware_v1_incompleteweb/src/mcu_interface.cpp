#include "mcu_interface.h"
#include "server.h"

Preferences prefs;

// set up SPI
// Define SPI interface pins
const int spi_sck = 19;
const int spi_miso = 17;
const int spi_mosi = 18;
const int spi_cs = 16;
SPIClass spi(HSPI);
uint32_t spi_baud = 100000;

static char input_line_serial[500];

QueueHandle_t q_wlan_led = xQueueCreate(10, sizeof(BlinkData_t));
SemaphoreHandle_t sem_wlan_led = xSemaphoreCreateBinary();
BlinkTaskMessaging_t blink_wlan = {q_wlan_led, sem_wlan_led};
QueueHandle_t q_ip_led = xQueueCreate(10, sizeof(BlinkData_t));
SemaphoreHandle_t sem_ip_led = xSemaphoreCreateBinary();
BlinkTaskMessaging_t blink_ip = {q_ip_led, sem_ip_led};
QueueHandle_t q_ap_led = xQueueCreate(10, sizeof(BlinkData_t));
SemaphoreHandle_t sem_ap_led = xSemaphoreCreateBinary();
BlinkTaskMessaging_t blink_ap = {q_ap_led, sem_ap_led};
QueueHandle_t q_websocket_led = xQueueCreate(10, sizeof(BlinkData_t));
SemaphoreHandle_t sem_websocket_led = xSemaphoreCreateBinary();
BlinkTaskMessaging_t blink_websocket = {q_websocket_led, sem_websocket_led};

SemaphoreHandle_t prefs_mutex;

// Define default pin for "command complete"
int comm_pin = 21;

// Define default pin for "network connected"
int net_pin = 22;

// Define default pin for "connected clients"
int connected_clients_pin = 32;

void blink_led_task(void * parameters) {
  BlinkTaskMessaging_t * blink_task_messaging = (BlinkTaskMessaging_t *) parameters;
  QueueHandle_t q = blink_task_messaging->q;
  // SemaphoreHandle_t sem = blink_task_messaging->sem;
  BlinkData_t q_data;
  BlinkData_t blink_data = {OFF, 255};
  uint32_t blink_delay;

  // Check NVS
  const char * task_name = pcTaskGetTaskName(NULL);
  // Serial.print("Starting task: ");
  // Serial.println(task_name);
  Serial.printf("Starting task: %s\r\n", task_name);

  xSemaphoreTake(prefs_mutex, portMAX_DELAY);
  if (!prefs.begin(task_name, true)) {
    log_e("Prefs open failed!");
  }
  blink_data.state = (blink_rate) prefs.getUChar("state", (uint8_t) OFF);
  blink_data.pin = prefs.getUChar("pin", (uint8_t) 255);
  prefs.end();
  xSemaphoreGive(prefs_mutex);
  // Serial.print("PIN STATE: ");
  // Serial.println(blink_data.state);
  // Serial.print("PIN NUM: ");
  // Serial.println(blink_data.pin);
  Serial.printf("%s - PIN STATE: %u, PIN NUM: %u\r\n", task_name, blink_data.state, blink_data.pin);

  while (1) {
    if (xQueueReceive(q, &q_data, 0) == pdTRUE) {
      if (q_data.state != NONE) {
        blink_data.state = q_data.state;

        // store in NVS
        xSemaphoreTake(prefs_mutex, portMAX_DELAY);
        if (!prefs.begin(task_name, false)) {
          log_e("Prefs open failed!");
        }
        if (!prefs.putUChar("state", (uint8_t) q_data.state)) {
          log_e("Prefs write failed");
        }
        prefs.end();
        xSemaphoreGive(prefs_mutex);
      }
      if (q_data.pin != 254) {
        blink_data.pin = q_data.pin;

        // store in NVS
        xSemaphoreTake(prefs_mutex, portMAX_DELAY);
        if (!prefs.begin(task_name, false)) {
          log_e("Prefs open failed!");
        }
        if (!prefs.putUChar("pin", q_data.pin)) {
          log_e("Prefs write failed");
        }
        prefs.end();
        xSemaphoreGive(prefs_mutex);
      }
    }

    if (blink_data.pin == 255) {
      vTaskDelay(2);
      continue;
    }

    pinMode(blink_data.pin, OUTPUT);
    if (blink_data.state != OFF) {
      switch (blink_data.state) {
        case SHORT :
          blink_delay = 125 / portTICK_PERIOD_MS;
          break;
        case MID :
          blink_delay = 500 / portTICK_PERIOD_MS;
          break;
        case LONG :
          blink_delay = 1000 / portTICK_PERIOD_MS;
          break;
        case OFF :
        default :
          break;
      }

      digitalWrite(blink_data.pin, !digitalRead(blink_data.pin));
      vTaskDelay(blink_delay);
    }
    else {
      digitalWrite(blink_data.pin, false);
    }
  }
}

void start_gpio_tasks() {
  // Task to blink LED to notify of internet connection
  xTaskCreate(
    blink_led_task,
    "blink_wlan",
    8192,
    (void*) &blink_wlan,
    1,
    NULL
  );

  // Task to blink LED to notify of provisioning mode
  xTaskCreate(
    blink_led_task,
    "blink_ap",
    8192,
    (void*) &blink_ap,
    1,
    NULL
  );

  // Task to blink LED to notify of websocket connection
  xTaskCreate(
    blink_led_task,
    "blink_websocket",
    8192,
    (void*) &blink_websocket,
    1,
    NULL
  );
}

void update_image(uint8_t * image, size_t len) {
  ws.broadcastBIN(image, len);
}

void receive_image(size_t len, bool verify = false) {
  if (verify) {
    Serial.printf("Receiving image over SPI (%u bytes)\r\n", len);
    Serial.printf("SPI baud rate: %u\r\n", spi_baud);
  }

  // allocate memory
  //uint8_t image[len];
  uint8_t* image = (uint8_t*)malloc(sizeof(uint8_t) * (len));
  
  // receive image over SPI
  digitalWrite(comm_pin, LOW);
  spi.beginTransaction(SPISettings(spi_baud, MSBFIRST, SPI_MODE0));
  digitalWrite(spi_cs, LOW);
  for (uint32_t ii=0;ii<len+1;ii++) {
    if (ii==0) {
      spi.transfer(0x00);
    } else {
      image[ii-1] = spi.transfer(0x00);
      // image[ii] = spi->transfer(0x00);
      //image[ii] = spi->transfer(ii);
    }
    //delayMicroseconds(1);
  }
  digitalWrite(spi_cs, HIGH);
  // spi->endTransaction();
  spi.endTransaction();
  digitalWrite(comm_pin, HIGH);
  
  update_image(image, len);
  
  if (verify) {
    Serial.println("Checking valid JPEG image");
    // Serial.println(image[0], HEX);
    // Serial.println(image[1], HEX);
    // Serial.println(image[len-2], HEX);
    // Serial.println(image[len-1], HEX);
    bool image_ok = true;
    if (image[0] != 0xFF || image[1] != 0xD8 || image[len-2] != 0xFF || image[len-1] != 0xD9) {
      image_ok = false;
    }
    if (image_ok) Serial.println("Image received properly on ESP32");
    else Serial.println("Image NOT received properly on ESP32");
  }

  free(image);
}

uint8_t get_prefs_data_gpios(const char * id, uint8_t default_val) {
  xSemaphoreTake(prefs_mutex, portMAX_DELAY);
  if (!prefs.begin("gpios", true)) {
    log_e("Prefs open failed!");
  }
  uint8_t ret = prefs.getUChar(id, default_val);
  prefs.end();
  xSemaphoreGive(prefs_mutex);

  return ret;
}

uint32_t get_prefs_data_vals(const char * id, uint32_t default_val) {
  xSemaphoreTake(prefs_mutex, portMAX_DELAY);
  if (!prefs.begin("user_vals", true)) {
    log_e("Prefs open failed!");
  }
  uint32_t ret = prefs.getULong(id, default_val);
  prefs.end();
  xSemaphoreGive(prefs_mutex);

  return ret;
}

void set_prefs_data_gpios(const char * id, uint8_t val) {
  xSemaphoreTake(prefs_mutex, portMAX_DELAY);
  if (!prefs.begin("gpios", false)) {
    log_e("Prefs open failed!");
  }
  if (!prefs.putUChar(id, val)) {
    log_e("Prefs write failed");
  }
  prefs.end();
  xSemaphoreGive(prefs_mutex);

  Serial.printf("Prefs: set %s to %u\r\n", id, val);
}

void set_prefs_data_vals(const char * id, uint32_t val) {
  xSemaphoreTake(prefs_mutex, portMAX_DELAY);
  if (!prefs.begin("user_vals", false)) {
    log_e("Prefs open failed!");
  }
  if (!prefs.putULong(id, val)) {
    log_e("Prefs write failed");
  }
  prefs.end();
  xSemaphoreGive(prefs_mutex);

  Serial.printf("Prefs: set %s to %u\r\n", id, val);
}

void process_data_serial() {
  // Serial.println(input_line_serial);

  digitalWrite(comm_pin, LOW);

  if (strstr(input_line_serial, "test") - input_line_serial == 0) {
    Serial.println("SUCCESS");
    Serial2.println("SUCCESS");
    delay(2);
  }
  else if (strstr(input_line_serial, "**$$") - input_line_serial == 0) {
    // special sequence to mirror transmission
    char* p = strstr(input_line_serial, "**$$");
    p += 4;
    Serial.println(p);
  }
  else if (strstr(input_line_serial, "ver") - input_line_serial == 0) {
    Serial.println("EE 326 ESP32 firmware version 1.0");
  }
  else if (strstr(input_line_serial, "image_transfer")) {
    char* p = strstr(input_line_serial, "image_transfer");
    p += 15; // get rid of "image_transfer"
    uint32_t len = atoi(p);
    // Serial.println(len, DEC);
    Serial.printf("Received image (%u bytes)\r\n", len);

    receive_image(len);
  }
  else if (strstr(input_line_serial, "image_test")) {
    char* p = strstr(input_line_serial, "image_test");
    p += 11; // get rid of "image_test"
    uint32_t len = atoi(p);
    // Serial.println(len, DEC);

    receive_image(len, true);
  }
  else if (strstr(input_line_serial, "set")) {
    char* p = strstr(input_line_serial, "set");
    p += 4; // retain only arguments after "set"
    if (strstr(p, "wlan_gpio")) {
      Serial.print("setting wlan gpio: ");
      char* c = strstr(p, "wlan_gpio");
      c += 10; // retain only pin number
      if (strstr(c, "off")) {
        Serial.println("off");
        BlinkData_t x = {OFF, 254};
        xQueueSend(q_wlan_led, (void *) &x, (TickType_t) 0);
      }
      else {
        uint8_t pin = atoi(c);
        Serial.println(pin, DEC);
        BlinkData_t x = {NONE, pin};
        xQueueSend(q_wlan_led, (void *) &x, (TickType_t) 0);
      }
    }
    else if (strstr(p, "websocket_gpio")) {
      Serial.print("setting websocket gpio: ");
      char* c = strstr(p, "websocket_gpio");
      c += 15; // retain only pin number
      if (strstr(c, "off")) {
        Serial.println("off");
        BlinkData_t x = {OFF, 254};
        xQueueSend(q_websocket_led, (void *) &x, (TickType_t) 0);
      }
      else {
        uint8_t pin = atoi(c);
        Serial.println(pin, DEC);
        BlinkData_t x = {NONE, pin};
        xQueueSend(q_websocket_led, (void *) &x, (TickType_t) 0);
      }
    }
    else if (strstr(p, "ap_gpio")) {
      Serial.print("setting AP gpio: ");
      char* c = strstr(p, "ap_gpio");
      c += 8; // retain only pin number
      if (strstr(c, "off")) {
        Serial.println("off");
        BlinkData_t x = {OFF, 254};
        xQueueSend(q_ap_led, (void *) &x, (TickType_t) 0);
      }
      else {
        uint8_t pin = atoi(c);
        Serial.println(pin, DEC);
        BlinkData_t x = {NONE, pin};
        xQueueSend(q_ap_led, (void *) &x, (TickType_t) 0);
      }
    }
    else if (strstr(p, "comm_gpio")) {
      Serial.print("setting command complete gpio: ");
      char* c = strstr(p, "comm_gpio");
      c += 10; // retain only pin number
      uint8_t pin = atoi(c);
      Serial.println(pin, DEC);
      pinMode(comm_pin, INPUT); // set old pin back to input (default)
      comm_pin = pin;
      pinMode(comm_pin, OUTPUT);
      digitalWrite(comm_pin, HIGH);
      set_prefs_data_gpios("comm_pin", comm_pin);
    }
    else if (strstr(p, "net_gpio")) {
      Serial.print("setting network gpio: ");
      char* c = strstr(p, "net_gpio");
      c += 9; // retain only pin number
      uint8_t pin = atoi(c);
      Serial.println(pin, DEC);
      pinMode(net_pin, INPUT); // set old pin back to input (default)
      net_pin = pin;
      pinMode(net_pin, OUTPUT);
      set_prefs_data_gpios("net_pin", net_pin);

      // check if connected to wifi to set proper level
      if (wifi_conn_status()) {
        digitalWrite(net_pin, HIGH);
      }
      else {
        digitalWrite(net_pin, LOW);
      }
    }
    else if (strstr(p, "clients_gpio")) {
      Serial.print("setting network gpio: ");
      char* c = strstr(p, "clients_gpio");
      c += 13; // retain only pin number
      uint8_t pin = atoi(c);
      Serial.println(pin, DEC);
      pinMode(connected_clients_pin, INPUT); // set old pin back to input (default)
      connected_clients_pin = pin;
      pinMode(connected_clients_pin, OUTPUT);
      set_prefs_data_gpios("clients_pin", connected_clients_pin);

      // check if connected to wifi to set proper level
      if (wifi_conn_status()) {
        digitalWrite(net_pin, HIGH);
      }
      else {
        digitalWrite(net_pin, LOW);
      }
    }
    else if (strstr(p, "spi_baud")) {
      Serial.print("setting SPI baud rate: ");
      char* c = strstr(p, "spi_baud");
      c += 9; // retain only pin number
      uint32_t baud = atoi(c);
      Serial.println(baud, DEC);
      spi_baud = baud;
      set_prefs_data_vals("spi_baud", spi_baud);
    }
  }
  else if (strstr(input_line_serial, "get")) {
    char* p = strstr(input_line_serial, "get");
    p += 4; // retain only arguments after "get"
    if (strstr(p, "mac")) {
      Serial.print("getting MAC address: ");
      Serial.println(get_mac_address());
    }
  }
  else if (strstr(input_line_serial, "provision")) {
    Serial.println("Going into web setup mode");
    web_setup = true;
  }

  digitalWrite(comm_pin, HIGH);
}

void process_incoming_byte_serial(uint8_t in_byte) {
  static uint8_t pos = 0;
  char end_marker = '\n';

  if (in_byte != end_marker) {
    input_line_serial[pos++] = in_byte;
    // Serial.print(in_byte);
  } else {
    input_line_serial[pos] = '\0';
    pos = 0;
    // Serial.println("received command, processing...");
    process_data_serial();
  }
}

void set_network_pin(uint8_t level) {
  digitalWrite(net_pin, level);
}

void set_connected_clients_pin(uint8_t level) {
  digitalWrite(connected_clients_pin, level);
}

void configure_gpio() {
  comm_pin = get_prefs_data_gpios("comm_pin", comm_pin);
  Serial.printf("Comm pin set to: %u\r\n", comm_pin);
  net_pin = get_prefs_data_gpios("net_pin", net_pin);
  Serial.printf("Network pin set to: %u\r\n", net_pin);
  connected_clients_pin = get_prefs_data_gpios("clients_pin", connected_clients_pin);
  Serial.printf("Connected clients pin set to: %u\r\n", connected_clients_pin);

  pinMode(spi_cs, OUTPUT);
  digitalWrite(spi_cs, HIGH);

  pinMode(comm_pin, OUTPUT);
  digitalWrite(comm_pin, HIGH);

  pinMode(net_pin, OUTPUT);
  digitalWrite(net_pin, LOW);

  pinMode(connected_clients_pin, OUTPUT);
  digitalWrite(connected_clients_pin, LOW);
}

void configure_vals() {
  spi_baud = get_prefs_data_vals("spi_baud", spi_baud);
  Serial.printf("SPI baud rate set to: %u\r\n", spi_baud);
}

void process_incoming_serial_task(void * params) {
  while (1) {
    while (Serial2.available()) {
      process_incoming_byte_serial(Serial2.read());
    }
    vTaskDelay(2);
  }
}

void start_incoming_serial_task() {
  xTaskCreate(
    process_incoming_serial_task,
    "incoming_serial",
    8192,
    NULL,
    1,
    NULL
  );
}

void start_mcu_interface() {
  // Create mutex for accessing SPIFFS
  prefs_mutex = xSemaphoreCreateMutex();
  if( prefs_mutex == NULL )
  {
      Serial.println("Error creating mutex!");
  }

  // Start SPI interface
  spi.begin(spi_sck, spi_miso, spi_mosi, spi_cs);

  // Start task to handle incoming serial data
  start_incoming_serial_task();

  // Configure and start GPIO tasks
  configure_gpio();
  configure_vals();
  start_gpio_tasks();
}