#ifndef MCU_INTERFACE_H_
#define MCU_INTERFACE_H_

#include <Arduino.h>
#include <SPI.h>
#include <Preferences.h>

void blink_led_task(void * parameters);
void process_incoming_byte_serial(uint8_t in_byte);
void start_mcu_interface();
void set_network_pin(uint8_t level);
void set_connected_clients_pin(uint8_t level);

// ENUM blink rates: OFF, SHORT, MID, LONG (NONE is no change from before)
enum blink_rate {NONE, OFF, SHORT, MID, LONG};

typedef struct BlinkTaskMessaging_t {
    QueueHandle_t q;
    SemaphoreHandle_t sem;
} BlinkTaskMessaging_t;

typedef struct BlinkData_t {
    blink_rate state;
    uint8_t pin; // 255 - none, 254 - no change
} BlinkData_t;

extern QueueHandle_t q_wlan_led;
extern QueueHandle_t q_ip_led;
extern QueueHandle_t q_ap_led;
extern QueueHandle_t q_websocket_led;

extern SemaphoreHandle_t sem_wlan_led;
extern SemaphoreHandle_t sem_ip_led;
extern SemaphoreHandle_t sem_ap_led;
extern SemaphoreHandle_t sem_websocket_led;

#endif