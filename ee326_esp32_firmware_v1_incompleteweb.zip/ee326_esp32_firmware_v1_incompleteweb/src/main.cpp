#include "mcu_interface.h"
#include "server.h"
#include "filesystem.h"

void setup(){
  // Serial port for debugging purposes
  Serial.begin(115200);

  // Serial port for communication with MCU
  Serial2.begin(115200, SERIAL_8N1, 15, 13);

  // Initialize SPIFFS
  uint8_t spiffs_check = startSPIFFS();
  if (spiffs_check == 1) {
    Serial.println("SPIFFS ERROR!");
    return;
  }

  start_mcu_interface();

  start_web_services();
}

void loop() {
  //  Nothing to do as everything is in tasks
  vTaskDelay(2);
}