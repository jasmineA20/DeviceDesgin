/*
 * wifi.h
 *
 */ 
#ifndef WIFI_H_
#define WIFI_H_

#include <asf.h>
#include <string.h>

volatile char input_line_wifi[1000];
volatile uint32_t input_pos_wifi;

volatile bool provision_flag;
volatile bool usart_comm_flag;
volatile bool test_success_flag;


// USART DEFINITIONS // 
#define WIFI_ID_USART               ID_USART0
#define WIFI_USART                  USART0
#define WIFI_USART_BAUDRATE         115200
#define WIFI_USART_IRQn			    USART0_IRQn
#define wifi_usart_handler          USART0_Handler
#define wifi_spi_handler            SPI_Handler

#define LED_PIN		PIO_PA20_IDX

#define ALL_INTERRUPT_MASK  0xffffffff

/** USART0 pin RX */
#define PIN_USART0_RXD	            {PIO_PA5A_RXD0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_PULLUP}
#define PIN_USART0_RXD_IDX          (PIO_PA5_IDX)
#define PIN_USART0_RXD_FLAGS        (PIO_PERIPH_A | PIO_PULLUP)
/** USART0 pin TX */
#define PIN_USART0_TXD              {PIO_PA6A_TXD0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_PULLUP}
#define PIN_USART0_TXD_IDX          (PIO_PA6_IDX)
#define PIN_USART0_TXD_FLAGS        (PIO_PERIPH_A | PIO_PULLUP)

#define WIFI_COMM_PIN_NUM			PIO_PB10
#define WIFI_COMM_PIO				PIOB
#define WIFI_COMM_ID				ID_PIOB
#define WIFI_COMM_MASK				PIO_PB10_IDX
#define WIFI_COMM_ATTR				PIO_IT_RISE_EDGE


// PROVISIONING PIN/BUTTON DEFINITIONS //
#define PROV_PUSH_BUTTON_PIN_MSK       PIO_PA22
#define PROV_PUSH_BUTTON_PIO           PIOA
#define PROV_PUSH_BUTTON_ID            ID_PIOA
#define PROV_PUSH_BUTTON_ATTR          PIO_PULLUP | PIO_DEBOUNCE | PIO_IT_RISE_EDGE

volatile uint32_t counter;
volatile uint32_t button_flag;


// SPI DEFINITIONS //
/** SPI MISO pin definition. */
#define SPI_MISO_GPIO        (PIO_PA12_IDX)
#define SPI_MISO_FLAGS       (PIO_PERIPH_A | PIO_DEFAULT)
/** SPI MOSI pin definition. */
#define SPI_MOSI_GPIO        (PIO_PA13_IDX)
#define SPI_MOSI_FLAGS       (PIO_PERIPH_A | PIO_DEFAULT)
/** SPI SPCK pin definition. */
#define SPI_SPCK_GPIO        (PIO_PA14_IDX)
#define SPI_SPCK_FLAGS       (PIO_PERIPH_A | PIO_DEFAULT)

/** SPI chip select 0 pin definition. (Only one configuration is possible) */
#define SPI_NPCS0_GPIO         (PIO_PA11_IDX)
#define SPI_NPCS0_FLAGS        (PIO_PERIPH_A | PIO_DEFAULT)

/* Chip select. */
#define SPI_CHIP_SEL 0
#define SPI_CHIP_PCS spi_get_pcs(SPI_CHIP_SEL)

/* Clock polarity. */
#define SPI_CLK_POLARITY 0

/* Clock phase. */
#define SPI_CLK_PHASE 0//1

/* Delay before SPCK. */
#define SPI_DLYBS 0x40

/* Delay between consecutive transfers. */
#define SPI_DLYBCT 0x10

volatile uint32_t transfer_index;
volatile uint32_t transfer_len;

/**
* @brief Handler for incoming data from the WiFi. Should call process incoming byte wifi when a new byte arrives.
*/
void wifi_usart_handler(void);

/**
 * @brief Stores every incoming byte (in byte) from the ESP32 in a buffer
 * 
 * @param in_byte 
 */
void process_incoming_byte_wifi(uint8_t in_byte);

/**
 * @brief Handler for �command complete� rising-edge interrupt from ESP32. When this is triggered, it is time to process
the response of the ESP32.
 * 
 * @param ul_id 
 * @param ul_mask 
 */
void wifi_command_response_handler(uint32_t ul_id, uint32_t ul_mask);

/**
 * @brief Processes the response of the ESP32, which should be stored in
the buffer filled by process incoming byte wifi. This processing should be looking for certain
responses that the ESP32 should give, such as �SUCCESS� when �test� is sent to it.
 * 
 */
void process_data_wifi(void);

/**
 * @brief Handler for button to initiate provisioning mode of the ESP32. Should set a flag indicating a request to initiate provisioning
mode.
 * 
 * @param ul_id 
 * @param ul_mask 
 */
void wifi_provision_handler(uint32_t ul_id, uint32_t ul_mask);

/**
 * @brief Handler for peripheral mode interrupts on SPI bus. When the
ESP32 SPI controller requests data, this interrupt should send one byte of the image at a time.
 * 
 */
void wifi_spi_handler(void);

/**
 * @brief Configuration of USART port used to communicate with the ESP32.
 * 
 */
void configure_usart_wifi(void);

/**
 * @brief Configuration of �command complete� rising-edge interrupt.
 * 
 */
void configure_wifi_comm_pin(void);

/**
 * @brief Configuration of button interrupt to initiate provisioning mode.
 * 
 */
void configure_wifi_provision_pin(void);

/**
 * @brief Configuration of SPI port used to send images to the ESP32.
 * 
 */
void configure_spi(void);

/**
 * @brief Initialize the SPI port as a peripheral (slave) device.
 * 
 */
void spi_peripheral_initialize(void);

/**
 * @brief Set necessary parameters to prepare for SPI transfer.
 * 
 */
void prepare_spi_transfer(void);

/**
 * @brief Writes a command (comm) to the ESP32, and waits either for an acknowledgment or a timeout. The timeout can be created by setting the
global variable counts to zero, which will automatically increment every second, and waiting while counts <cnt.
 * 
 * @param comm 
 * @param cnt 
 */
void write_wifi_command(char* comm, uint8_t cnt);

/**
 * @brief Writes an image from the SAM4S8B to the ESP32. If the length of the image is zero (i.e. the image is not valid), return.
 * 
 */
void write_image_to_web(void);



#endif



